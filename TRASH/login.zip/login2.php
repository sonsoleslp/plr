<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Starter Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <style>
        body {
            padding-top: 50px;
        }

        .starter-template {
            padding: 40px 15px;
            text-align: center;
        }
    </style>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-10 col-mds-push-1 col-lg-6 col-lg-push-3">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h2 class="form-signing-heading">Login</h2>
                </div>
                <div class="panel-body">
                    <form action="procesaLogin.php" method="post" class="form-signin">


                        <div class="form-group">
                            <label class="sr-only" for="exampleInputAmount">Username</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                <input type="text" class="form-control" name="username" id="username" placeholder="Usuario">

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="sr-only" for="exampleInputAmount">Username</label>
                            <div class="input-group">
                                <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña">

                            </div>
                        </div>
                        <br>
                        <button class="btn btn-lg btn-primary btn-block">
                            Entrar
                        </button>
                        <br>
                        <?php if (isset($_REQUEST['errorLogin'])): ?>
                            <div class="panel panel-danger">
                                <div class="panel-heading">
                                    Error
                                </div>
                                <div class="panel-body">
                                    <p><?php  echo "Error en el inicio de sesión."?></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
                <div class="panel-footer"></div>
            </div>
        </div>
    </div>

</div>
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</body>
</html>
