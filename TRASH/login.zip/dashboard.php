<?php
/**
 * Created by PhpStorm.
 * User: Sonsoles
 * Date: 27/04/2016
 * Time: 14:02
 */

require_once("restringido.php");?>

PÁGINA PROTEGIDA
