<?php
/**
 * Created by PhpStorm.
 * User: Sonsoles
 * Date: 13/04/2016
 * Time: 22:43
 */

define("RECIPIENT_NAME","TEWC");
define("RECIPIENT_ADDRESS","sonsoleslp@hotmail.com");
define("EMAIL_SUBJECT","Ejercicio PHP");
$senderEmail = $_REQUEST['email'];
if (!isset($senderEmail)){
    $errorEmail = "Debe escribir una dirección de correo";

} else {
    $senderEmail = filter_var($senderEmail, FILTER_SANITIZE_EMAIL);
    if(!filter_var($senderEmail, FILTER_VALIDATE_EMAIL)){
        $errorEmail = "Dirección de correo incorrecta";
    }
}
$senderName = $_REQUEST['name'];
if (!isset($senderName)){
    $errorName = "Debe escribir su nombre";

} else {
    $senderName = filter_var($senderName, FILTER_SANITIZE_STRING);
    if($senderName==""){
        $errorName = "Debe escribir un nombre válido";
    }
}

$message = $_REQUEST['message'];
if (!isset($message)){
    $errorMessage = "Debe escribir un mensaje";

} else {
    $message = filter_var($message, FILTER_SANITIZE_STRING);
    if($message == ""){
        $errorMessage = "Debe escribir un mensaje válido";
    }
}

$sucess=false;
if(!isset($errorEmail) && !isset($errorName) && !isset($errorMessage)){
    $recipient = RECIPIENT_NAME . " <" . RECIPIENT_ADDRESS . ">";
    $headers = "From: " . $senderName . " <" . $senderEmail . ">";
    $success = mail($recipient, EMAIL_SUBJECT, $message, $headers);

}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Procesa contaco</title>
		<meta charset="UTF-8">
		<meta name=description content="">
		<meta name=viewport content="width=device-width, initial-scale=1">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Bootstrap CSS -->
		<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" media="screen">
	</head>
	<body>
    <div class="container">
        <h2>Mensaje</h2>
        <ul>
            <li>Receptor: <?php echo htmlspecialchars($recipient); ?></li>
            <li>Tema: <?php echo EMAIL_SUBJECT; ?></li>
            <li>Mensaje: <?php echo htmlspecialchars($message); ?></li>
            <li>Cabeceras: <?php echo htmlspecialchars($headers); ?></li>
        </ul>

    <?php
    if($success):
        ?>
        <div class="panel panel-success">
            <p>Gracias por enviar su mensaje! Nos pondremos en contacto cuanto antes.</p>
        </div>
    <?php
    else:
    ?>
        <div class="panel panel-danger">
            <p>Lo sentimos, ha habido un problema al enviar su mensaje. Por favor, inténtelo de nuevo.</p>
            <?php echo $errorMessage ;?><br>
            <?php echo $errorEmail ;?><br>
            <?php echo $errorName ;?><br>


        </div>
    <?php endif ?>
    <footer class="footer">
        <div class="container">
            <p class="text-muted">Volver a <a href="/formcorreo.html"> Página inicial</a></p>
        </div>
    </footer>
    </div>
		<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
	</body>
</html>