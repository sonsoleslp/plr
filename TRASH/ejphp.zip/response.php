

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Title</title>
    <meta charset="UTF-8">
    <meta name=description content="">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>
<body>
<div class="container">
    <h1>Ejemplos Extra PHP</h1>
    <div class="row">
        <div class="col-xs-12">
            <?php
            foreach ($_REQUEST as $key => $key) {
                echo "<p>Clave " . $key . " y Valor " .  "$_REQUEST[$key]</p>";

            }
            echo "<p>Nombre: " . $_REQUEST['nombre']. "</p>";
            echo "<p>Edad: " . $_REQUEST['edad']. "</p>";
            ?>
        </div>
    </div>







<!-- jQuery -->
<script src="//code.jquery.com/jquery.js"></script>
<!--

Bootstrap JavaScript -->
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
</body>
</html>